class CfgPatches
{
	class WPS_Weapons_Magazines_Blasters
	{
		weapons[]=
		{
		};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"A3_Weapons_F"
		};
		magazines[]=
		{
			"WPS_ChargePack_DX11_Standard",
			"WPS_ChargePack_DX11_Ion",
			"WPS_ChargePack_DC15_VeryLow",
			"WPS_ChargePack_DC15_Low",
			"WPS_ChargePack_DC15_Medium",
			"WPS_ChargePack_DC15_High",
			"WPS_ChargePack_DC15_VeryHigh",
			"WPS_ChargePack_DC15_Sniper",
			"WPS_ChargePack_DC17_Low",
			"WPS_ChargePack_DC17_High",
			"WPS_ChargePack_DC17_StunBlue",
			"WPS_ShotPack_DLT18_Buckshot",
			"WPS_ShotPack_DLT18_Slug",
			"WPS_ShotPack_DLT18_Stun",
			"WPS_ShotPack_DLT18_Incendiary",
			"WPS_ShotPack_DLT18_Ion"
		};
		ammo[]=
		{
			"WPS_BlasterBolt_VeryLowPowerBlue",
			"WPS_BlasterBolt_LowPowerBlue",
			"WPS_BlasterBolt_MediumPowerBlue",
			"WPS_BlasterBolt_HighPowerBlue",
			"WPS_BlasterBolt_VeryHighPowerBlue",
			"WPS_BlasterBolt_MaximumPowerBlue",
			"WPS_BlasterBolt_StunBlue",
			"WPS_BlasterBolt_IonBlue",
			"WPS_ShotgunShell_Buckshot",
			"WPS_ShotgunShell_Slug",
			"WPS_ShotgunShell_Stun",
			"WPS_ShotgunShell_Ion"
		};
		units[]={};
	};
};
class CfgAmmo
{
	class BulletBase;
	class WPS_BlasterBolt_Base: BulletBase
	{
		visibleFire = 5;
		audibleFire = 20;
		visibleFireTime = 2;
		dangerRadiusBulletClose = 4;
		dangerRadiusHit = -1;
		suppressionRadiusBulletClose = 2;
		suppressionRadiusHit = 4;
		hit = 1;
		indirectHit = 0;
		indirectHitRange = 0;
		model = "WPS\WPS_Weapons\Magazines\Blasters\Data\BlasterBolt_Blue.p3d";
		caliber = 1;
		ACE_caliber = 1;
		WPS_AmmoType = 1;
		coefGravity = 0.01;
		cartridge = "";
		cost = 1;
		timeToLive = 10;
		deflecting = 0;
		ExplosionEffects = "WPS_ImpactBlasterBolt";
		craterEffects = "";
		explosive = 0.1;
		tracerStartTime = 0;
		tracerEndTime = 10;
		airFriction = -0.0003;
		muzzleEffect = "";
		waterEffectOffset = 0.8;
		effectFly = "WPS_FX_Bullet_Teal";
		aiAmmoUsageFlags = "64 + 128 + 256";
		soundHitBody1[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-01.ogg",3,1,200};
		soundHitBody2[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-02.ogg",3,1,200};
		soundHitBody3[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-03.ogg",3,1,200};
		soundHitBody4[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-04.ogg",3,1,200};
		soundHitBody5[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-05.ogg",3,1,200};
		soundHitBody6[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-06.ogg",3,1.5,200};
		soundHitBody7[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-07.ogg",3,1.5,200};
		soundHitBody8[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-08.ogg",3,1.5,200};
		soundHitBody9[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-03.ogg",3,1.5,200};
		soundHitBody10[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Body-02.ogg",3,1.5,200};
		hitMan[] = {"soundHitBody1",0.1,"soundHitBody2",0.1,"soundHitBody3",0.1,"soundHitBody4",0.1,"soundHitBody5",0.1,"soundHitBody6",0.1,"soundHitBody7",0.1,"soundHitBody8",0.1,"soundHitBody9",0.1,"soundHitBody10",0.1};
		soundDefault1[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-01.ogg",2,1,165};
		soundDefault2[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-02.ogg",2,1,165};
		soundDefault3[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-03.ogg",2,1,165};
		soundDefault4[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-04.ogg",2,1,165};
		soundDefault5[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-05.ogg",2,1,165};
		soundDefault6[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-06.ogg",2,1,165};
		soundDefault7[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-07.ogg",2,1,165};
		soundDefault8[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-08.ogg",2,1,165};
		soundDefault9[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-09.ogg",2,1,165};
		soundDefault10[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-10.ogg",2,1,165};
		soundDefault11[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-11.ogg",2,1,165};
		soundDefault12[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-12.ogg",2,1,165};
		soundDefault13[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-13.ogg",2,1,165};
		soundDefault14[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-14.ogg",2,1,165};
		soundDefault15[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-15.ogg",2,1,165};
		soundDefault16[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-16.ogg",2,1,165};
		soundDefault17[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-17.ogg",2,1,165};
		soundDefault18[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-18.ogg",2,1,165};
		soundDefault19[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-19.ogg",2,1,165};
		soundDefault20[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-20.ogg",2,1,165};
		soundDefault21[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-21.ogg",2,1,165};
		soundDefault22[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-01.ogg",2,1,165};
		soundDefault23[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-02.ogg",2,1,165};
		soundDefault24[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-03.ogg",2,1,165};
		soundDefault25[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-04.ogg",2,1,165};
		soundDefault26[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-05.ogg",2,1,165};
		soundDefault27[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-06.ogg",2,1,165};
		soundDefault28[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-07.ogg",2,1,165};
		soundDefault29[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-08.ogg",2,1,165};
		soundDefault30[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-09.ogg",2,1,165};
		soundDefault31[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-10.ogg",2,1,165};
		soundDefault32[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-11.ogg",2,1,165};
		soundDefault33[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-12.ogg",2,1,165};
		soundDefault34[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-13.ogg",2,1,165};
		soundDefault35[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-14.ogg",2,1,165};
		soundDefault36[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-15.ogg",2,1,165};
		soundDefault37[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-16.ogg",2,1,165};
		soundDefault38[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Tree-01.ogg",2,1,165};
		soundDefault39[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Tree-02.ogg",2,1,165};
		hitDefault[] = {"soundDefault1",0.027,"soundDefault2",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		hitFoliage[] = {"soundDefault1",0.027,"soundDefault2",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		hitPlastic[] = {"soundDefault1",0.027,"soundDefault2",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		hitRubber[] = {"soundDefault1",0.027,"soundDefault2",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		hitTyre[] = {"soundDefault1",0.027,"soundDefault2",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		hitWood[] = {"soundDefault38",0.027,"soundDefault39",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		hitBuilding[] = {"soundDefault1",0.027,"soundDefault2",0.027,"soundDefault3",0.027,"soundDefault4",0.027,"soundDefault5",0.027,"soundDefault6",0.027,"soundDefault7",0.027,"soundDefault8",0.027,"soundDefault9",0.027,"soundDefault10",0.027,"soundDefault11",0.027,"soundDefault12",0.027,"soundDefault13",0.027,"soundDefault14",0.027,"soundDefault15",0.027,"soundDefault16",0.027,"soundDefault17",0.027,"soundDefault18",0.027,"soundDefault19",0.027,"soundDefault20",0.027,"soundDefault21",0.027,"soundDefault22",0.027,"soundDefault23",0.027,"soundDefault24",0.027,"soundDefault25",0.027,"soundDefault26",0.027,"soundDefault37",0.027,"soundDefault27",0.027,"soundDefault28",0.027,"soundDefault29",0.027,"soundDefault30",0.027,"soundDefault31",0.027,"soundDefault32",0.027,"soundDefault33",0.027,"soundDefault34",0.027,"soundDefault35",0.027,"soundDefault36",0.027};
		soundHit1[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-01.ogg",2,1,165};
		soundHit2[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-02.ogg",2,1,165};
		soundHit3[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-03.ogg",2,1,165};
		soundHit4[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-04.ogg",2,1,165};
		soundHit5[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-05.ogg",2,1,165};
		soundHit6[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-06.ogg",2,1,165};
		soundHit7[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-01.ogg",2,1,165};
		soundHit8[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-02.ogg",2,1,165};
		soundHit9[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-03.ogg",2,1,165};
		soundHit10[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-04.ogg",2,1,165};
		soundHit11[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_Dirt-05.ogg",2,1,165};
		hitGround[] = {"soundHit1",0.0909,"soundHit2",0.0909,"soundHit3",0.0909,"soundHit4",0.0909,"soundHit5",0.0909,"soundHit6",0.0909,"soundHit7",0.0909,"soundHit8",0.0909,"soundHit9",0.0909,"soundHit10",0.0909,"soundHit11",0.0909};
		hitGroundHard[] = {"soundHit1",0.0909,"soundHit2",0.0909,"soundHit3",0.0909,"soundHit4",0.0909,"soundHit5",0.0909,"soundHit6",0.0909,"soundHit7",0.0909,"soundHit8",0.0909,"soundHit9",0.0909,"soundHit10",0.0909,"soundHit11",0.0909};
		hitGroundSoft[] = {"soundHit1",0.0909,"soundHit2",0.0909,"soundHit3",0.0909,"soundHit4",0.0909,"soundHit5",0.0909,"soundHit6",0.0909,"soundHit7",0.0909,"soundHit8",0.0909,"soundHit9",0.0909,"soundHit10",0.0909,"soundHit11",0.0909};
		hitConcrete[] = {"soundHit1",0.0909,"soundHit2",0.0909,"soundHit3",0.0909,"soundHit4",0.0909,"soundHit5",0.0909,"soundHit6",0.0909,"soundHit7",0.0909,"soundHit8",0.0909,"soundHit9",0.0909,"soundHit10",0.0909,"soundHit11",0.0909};
		soundMetal1[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-01.ogg",2,1,165};
		soundMetal2[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-02.ogg",2,1,165};
		soundMetal3[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-03.ogg",2,1,165};
		soundMetal4[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-04.ogg",2,1,165};
		soundMetal5[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-05.ogg",2,1,165};
		soundMetal6[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-06.ogg",2,1,165};
		soundMetal7[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-07.ogg",2,1,165};
		soundMetal8[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-08.ogg",2,1,165};
		soundMetal9[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-09.ogg",2,1,165};
		soundMetal10[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-01.ogg",2,1,165};
		soundMetal11[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-02.ogg",2,1,165};
		soundMetal12[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-03.ogg",2,1,165};
		soundMetal13[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-04.ogg",2,1,165};
		soundMetal14[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-20.ogg",2,1,165};
		soundMetal15[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact-21.ogg",2,1,165};
		hitMetal[] = {"soundMetal1",0.0666,"soundMetal2",0.0666,"soundMetal3",0.0666,"soundMetal4",0.0666,"soundMetal5",0.0666,"soundMetal6",0.0666,"soundMetal7",0.0666,"soundMetal8",0.0666,"soundMetal9",0.0666,"soundMetal10",0.0666,"soundMetal11",0.0666,"soundMetal12",0.0666,"soundMetal13",0.0666,"soundMetal14",0.0666,"soundMetal15",0.0666};
		hitIron[] = {"soundMetal1",0.0666,"soundMetal2",0.0666,"soundMetal3",0.0666,"soundMetal4",0.0666,"soundMetal5",0.0666,"soundMetal6",0.0666,"soundMetal7",0.0666,"soundMetal8",0.0666,"soundMetal9",0.0666,"soundMetal10",0.0666,"soundMetal11",0.0666,"soundMetal12",0.0666,"soundMetal13",0.0666,"soundMetal14",0.0666,"soundMetal15",0.0666};
		hitMetalInt[] = {"soundMetal1",0.0666,"soundMetal2",0.0666,"soundMetal3",0.0666,"soundMetal4",0.0666,"soundMetal5",0.0666,"soundMetal6",0.0666,"soundMetal7",0.0666,"soundMetal8",0.0666,"soundMetal9",0.0666,"soundMetal10",0.0666,"soundMetal11",0.0666,"soundMetal12",0.0666,"soundMetal13",0.0666,"soundMetal14",0.0666,"soundMetal15",0.0666};
		soundMetalPlate1[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-01.ogg",2,1,165};
		soundMetalPlate2[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-02.ogg",2,1,165};
		soundMetalPlate3[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-03.ogg",2,1,165};
		soundMetalPlate4[] = {"\WPS\WPS_Weapons\Sounds\Weapons\Blaster_Impact_SheetMetal-04.ogg",2,1,165};	
		hitMetalPlate[] = {"soundMetalPlate1",0.25,"soundMetalPlate2",0.25,"soundMetalPlate3",0.25,"soundMetalPlate4",0.25};
		hitArmor[] = {"soundMetal1",0.0666,"soundMetal2",0.0666,"soundMetal3",0.0666,"soundMetal4",0.0666,"soundMetal5",0.0666,"soundMetal6",0.0666,"soundMetal7",0.0666,"soundMetal8",0.0666,"soundMetal9",0.0666,"soundMetal10",0.0666,"soundMetal11",0.0666,"soundMetal12",0.0666,"soundMetal13",0.0666,"soundMetal14",0.0666,"soundMetal15",0.0666};
		hitArmorInt[] = {"soundMetal1",0.0666,"soundMetal2",0.0666,"soundMetal3",0.0666,"soundMetal4",0.0666,"soundMetal5",0.0666,"soundMetal6",0.0666,"soundMetal7",0.0666,"soundMetal8",0.0666,"soundMetal9",0.0666,"soundMetal10",0.0666,"soundMetal11",0.0666,"soundMetal12",0.0666,"soundMetal13",0.0666,"soundMetal14",0.0666,"soundMetal15",0.0666};
		soundFly[] = {"",0.251189,0.7};
		soundSetSonicCrack[] = {"WPS_BlasterBolt_FlyBy_Soundset"};
		class HitEffects
		{
			Hit_Foliage_green = "WPS_ImpactBlasterBolt";
			Hit_Foliage_Dead = "WPS_ImpactBlasterBolt";
			Hit_Foliage_Green_big = "WPS_ImpactBlasterBolt";
			Hit_Foliage_Palm = "WPS_ImpactBlasterBolt";
			Hit_Foliage_Pine = "WPS_ImpactBlasterBolt";
			hitFoliage = "WPS_ImpactBlasterBolt";
			hitGlass = "WPS_ImpactBlasterBolt";
			hitGlassArmored = "WPS_ImpactBlasterBolt";
			hitWood = "WPS_ImpactBlasterBolt";
			hitMetal = "WPS_ImpactBlasterBolt";
			hitMetalPlate = "WPS_ImpactBlasterBolt";
			hitBuilding = "WPS_ImpactBlasterBolt";
			hitPlastic = "WPS_ImpactBlasterBolt";
			hitRubber = "WPS_ImpactBlasterBolt";
			hitTyre = "WPS_ImpactBlasterBolt";
			hitConcrete = "WPS_ImpactBlasterBolt";
			hitMan = "WPS_ImpactBlasterBolt";
			hitGroundSoft = "WPS_ImpactBlasterBolt";
			hitGroundRed = "WPS_ImpactBlasterBolt";
			hitGroundHard = "WPS_ImpactBlasterBolt";
			hitWater = "WPS_ImpactBlasterBolt";
			hitVirtual = "WPS_ImpactBlasterBolt";
			default_mat = "WPS_ImpactBlasterBolt";
		};
	};
	class WPS_BlasterBolt_VeryLowPowerBlue: WPS_BlasterBolt_Base
	{
		hit = 5;
	};
	class WPS_BlasterBolt_LowPowerBlue: WPS_BlasterBolt_Base
	{
		hit = 11;
	};
	class WPS_BlasterBolt_MediumPowerBlue: WPS_BlasterBolt_Base
	{
		hit = 17;
	};
	class WPS_BlasterBolt_HighPowerBlue: WPS_BlasterBolt_Base
	{
		hit = 28;
	};
	class WPS_BlasterBolt_VeryHighPowerBlue: WPS_BlasterBolt_Base
	{
		hit = 40;
		caliber = 2;
		ACE_caliber = 2;
	};
	class WPS_BlasterBolt_MaximumPowerBlue: WPS_BlasterBolt_Base
	{
		hit = 100;
		caliber = 3;
		ACE_caliber = 3;
	};
	class WPS_BlasterBolt_StunBlue: WPS_BlasterBolt_Base
	{
		hit = 0.1;
		indirectHit = 0;
		indirectHitRange = 0;
		WPS_AmmoType = 2;
		model = "WPS\WPS_Weapons\Magazines\Blasters\Data\BlasterBoltStun_Blue.p3d";
		// Stun Duration for this is set in the WPS_Weapon_fnc_onHitStun sqf file.
	};
	class WPS_BlasterBolt_IonBlue: WPS_BlasterBolt_Base
	{
		hit = 17;
		indirectHit = 0;
		indirectHitRange = 0;
		WPS_AmmoType = 7;
	};
	class WPS_ShotgunShell_Buckshot: WPS_BlasterBolt_Base
	{
		hit = 20;
		caliber = 1.5;
		ACE_caliber = 1.5;
		simulation = "shotSpread";
		timetolive = 1.25;
		submunitionAmmo[] = {"WPS_BlasterBolt_MediumPowerBlue",0.6,"WPS_BlasterBolt_LowPowerBlue",0.3,"WPS_BlasterBolt_VeryLowPowerBlue",0.1};
		submunitionDirectionType = "SubmunitionModelDirection";
		submunitionConeType[] = {"poissondisc", 15 }; 
		triggerTime = 0.1;
		deleteParentWhenTriggered = true;
	};
	class WPS_ShotgunShell_Slug: WPS_BlasterBolt_Base
	{
		hit = 30;
		caliber = 2;
		ACE_caliber = 2;
		timeToLive = 3;
	};
	class WPS_ShotgunShell_Ion: WPS_BlasterBolt_Base
	{
		hit = 18;
		caliber = 1;
		ACE_caliber = 1;
		simulation = "shotSpread";
		timetolive = 1.5;
		submunitionAmmo[] = {"WPS_BlasterBolt_MediumPowerBlue",0.6,"WPS_BlasterBolt_LowPowerBlue",0.3,"WPS_BlasterBolt_VeryLowPowerBlue",0.1};
		submunitionDirectionType = "SubmunitionModelDirection";
		submunitionConeType[] = {"poissondisc", 15 }; 
		triggerTime = 0.1;
		deleteParentWhenTriggered = true;
		WPS_AmmoType = 7;
	};
	class WPS_ShotgunShell_Stun: WPS_BlasterBolt_Base
	{
		hit = 0.1;
		caliber = 1;
		ACE_caliber = 1;
		simulation = "shotSpread";
		timetolive = 1.5;
		submunitionAmmo[] = {"WPS_BlasterBolt_StunBlue",1};
		submunitionDirectionType = "SubmunitionModelDirection";
		submunitionConeType[] = {"poissondisc", 10 }; 
		triggerTime = 0.1;
		deleteParentWhenTriggered = false;
		WPS_AmmoType = 2;
	};
};
class CfgMagazines
{	
	class Default;
	class CA_Magazine: Default{};
	class WPS_ChargePack_Base: CA_Magazine
	{
		author = "Maldova";
		scope = 1;
		displayName = "[WPS] Charge Pack";
		picture = "\WPS\WPS_Weapons\Magazines\Blasters\UI\DC15SeriesMagazineIcon.paa";
		ammo = "WPS_BlasterBolt_HighPowerBlue";
		count = 50;
		tracersEvery = 1;
		lastRoundsTracer = 50;
		mass = 2;
		initSpeed = 320;
		descriptionShort = "Standard Charge Pack for the DC Platform of Weapons.";
	};
	class WPS_ChargePack_DC15_Low: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "[WPS] Low Charge Pack";
		ammo = "WPS_BlasterBolt_LowPowerBlue";
		descriptionShort = "Low Power Charge Pack for the DC Platform of Weapons.";
	};
	class WPS_ChargePack_DC15_Medium: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "[WPS] Medium Charge Pack";
		ammo = "WPS_BlasterBolt_MediumPowerBlue";
		descriptionShort = "Medium Power Charge Pack for the DC Platform of Weapons.";
	};
	class WPS_ChargePack_DC15_High: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "[WPS] High Charge Pack";
		ammo = "WPS_BlasterBolt_HeavyPowerBlue";
		descriptionShort = "High Charge Pack for the DC Platform of Weapons.";
	};
	class WPS_ChargePack_DC15H_Low:WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "[WPS] DC15H Low Charge Pack (200)";
		picture = "\WPS\WPS_Weapons\Magazines\Blasters\UI\DC15HMagazineIcon.paa";
		ammo = "WPS_BlasterBolt_VeryLowPowerBlue";
		descriptionShort = "Low-Power Charge Pack for the DC-15H.";
		count = 200;
		lastRoundsTracer = 200;
	};
	class WPS_ChargePack_DC15H_Medium:WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "[WPS] DC15H Medium Charge Pack (100)";
		picture = "\WPS\WPS_Weapons\Magazines\Blasters\UI\DC15HMagazineIcon.paa";
		ammo = "WPS_BlasterBolt_MediumPowerBlue";
		descriptionShort = "Medium-Power Charge Pack for the DC-15H.";
		count = 100;
		lastRoundsTracer = 100;
	};
	class WPS_ChargePack_DC17_Low: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC-17 Charge Pack (Low)";
		ammo = "WPS_BlasterBolt_LowPowerBlue";
		count = 50;
		lastRoundsTracer = 50;
		initSpeed = 300;
		descriptionShort = "Low-Power Charge Pack for the DC-17.";
	};
	class WPS_ChargePack_DC17_High: WPS_ChargePack_DC17_Low
	{
		scope = 2;
		displayName = "DC-17 Charge Pack (High)";
		ammo = "WPS_BlasterBolt_HighPowerBlue";
		count = 20;
		lastRoundsTracer = 20;
		initSpeed = 350;
		descriptionShort = "High-Power Charge Pack for the DC-17.";
	};
	class WPS_ChargePack_DC17_StunBlue: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC-17 Stun Pack";
		ammo = "WPS_BlasterBolt_StunBlue";
		count = 10;
		lastRoundsTracer = 10;
		initspeed = 150;
		descriptionShort = "Low Power Charge Pack for the DC-17.  Stuns for 20 seconds.";
		// Stun Duration for this is set in the WPS_Weapon_fnc_onHitStun sqf file.
	};
	class WPS_ShotPack_DLT18_Buckshot: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC Series Buckshot";
		ammo = "WPS_ShotgunShell_Buckshot";
		count = 15;
		lastRoundsTracer = 15;
		initSpeed = 400;
		descriptionShort = "Buckshot-Shotgun shells for use by the GAR.";
	};
	class WPS_ShotPack_DLT18_Slug: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC Series slug-shot";
		ammo = "WPS_ShotgunShell_Slug";
		count = 20;
		lastRoundsTracer = 20;
		initSpeed = 400;
		descriptionShort = "Slug-Shotgun shells for use by the GAR.";
	};
	class WPS_ShotPack_DLT18_Stun: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC Series Stun-shot";
		ammo = "WPS_ShotgunShell_Stun";
		count = 10;
		lastRoundsTracer = 10;
		initSpeed = 400;
		descriptionShort = "Stun-Shotgun shells for use by the GAR.";
	};
	class WPS_ShotPack_DLT18_Ion: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC Series Ion-shot";
		ammo = "WPS_ShotgunShell_Ion";
		count = 15;
		lastRoundsTracer = 15;
		initSpeed = 300;
		descriptionShort = "Ion-Shotgun shells for use by the GAR.";
	};
	class WPS_ShotPack_DLT18_Incendiary: WPS_ChargePack_Base
	{
		scope = 2;
		displayName = "DC Series Incendiary-shot";
		ammo = "WPS_BTX42_FireShot";
		count = 15;
		lastRoundsTracer = 15;
		initSpeed = 200;
		descriptionShort = "Incendiary-Shotgun shells for use by the GAR.";
	};
};
class CfgMagazineWells
{
	class WPS_DX11Magwell
	{
		DX11Magazines[] = 
		{
			"WPS_ChargePack_DX11_Standard",
			"WPS_ChargePack_DX11_Ion",
			"WPS_ChargePack_DC15_High"
		};
	};
	class WPS_DC15XMagwell
	{
		DC15XMagazines[] = 
		{
			"WPS_ChargePack_DX11_Standard",
			"WPS_ChargePack_DX11_Ion",
			"WPS_ChargePack_DC15_High",
			"WPS_ChargePack_DC15_Medium"
		};
	};
	class WPS_DC15AMagwell
	{
		DC15AMagazines[] = 
		{
			"WPS_ChargePack_DC15_Medium",
			"WPS_ChargePack_DC15_High"
		};
	};
	class WPS_DC15SMagwell
	{
		DC15SMagazines[] = 
		{
			"WPS_ChargePack_DC15_Low",
			"WPS_ChargePack_DC15_Medium"
		};
	};
	class WPS_DC15CMagwell
	{
		DC15CMagazines[] = 
		{
			"WPS_ChargePack_DC15_Low",
			"WPS_ChargePack_DC15_Medium"
		};
	};
	class WPS_DC15HMagwell
	{
		DC15HMagazines[] = 
		{
			"WPS_ChargePack_DC15H_Low",
			"WPS_ChargePack_DC15H_Medium"
		};
	};
	class WPS_DC17Magwell
	{
		DC17Magazines[] = 
		{
			"WPS_ChargePack_DC17_Low",
			"WPS_ChargePack_DC17_High"
		};
	};
	class WPS_DC17StunMagwell
	{
		DC17StunMagazines[] = 
		{
			"WPS_ChargePack_DC17_StunBlue"
		};
	};
	class WPS_DLT18Magwell
	{
		DLT18Magazines[] = 
		{
			"WPS_ShotPack_DLT18_Buckshot",
			"WPS_ShotPack_DLT18_Slug",
			"WPS_ShotPack_DLT18_Stun",
			"WPS_ShotPack_DLT18_Incendiary",
			"WPS_ShotPack_DLT18_Ion"
		};
	};
	class WPS_Valken38XMagwell
	{
		Valken38XMagazines[] = 
		{
			"WPS_ChargePack_DX11_Ion",
			"WPS_ChargePack_DC15_High"
		};
	};
};
class cfgRecoils
{
	class Default;
	class WPS_Recoil_Default: Default
	{
		kickBack[] = {0.025,0.06};
		muzzleInner[] = {0,0,0.1,0.1};
		muzzleOuter[] = {0.3,1,0.3,0.2};
		permanent = 0.1;
		temporary = 0.01;
	};
	class WPS_Recoil_Light: WPS_Recoil_Default
	{
		kickBack[] = {0.01,0.02};
		muzzleOuter[] = {0.1,0.4,0.2,0.2};
		temporary = 0.005;
	};
	class WPS_Recoil_Medium: WPS_Recoil_Default
	{
		kickBack[] = {0.04,0.07};
		muzzleOuter[] = {0.5,1.5,0.5,0.4};
		temporary = 0.02;
	};
	class WPS_Recoil_Heavy: WPS_Recoil_Default
	{
		kickBack[] = {0.1,0.12};
		muzzleOuter[] = {1.4,3.5,0.8,0.8};
		temporary = 0.08;
	};
	class WPS_Recoil_DC15A: WPS_Recoil_Default
	{
		muzzleOuter[] = {0.3,0.8,0.4,0.3};
		kickBack[] = {0.03,0.06};
		temporary = 0.01;
	};
	class WPS_Recoil_DC15S: WPS_Recoil_Default
	{
		kickBack[] = {0.01,0.02};
		muzzleOuter[] = {0.1,0.55,0.2,0.3};
		permanent = 0.08;
		temporary = 0.005;
	};
	class WPS_Recoil_DC15L: WPS_Recoil_Default
	{
		muzzleOuter[] = {0.3,0.8,0.4,0.2};
		kickBack[] = {0.02,0.04};
		temporary = 0.01;
	};
	class WPS_Recoil_DC15C: WPS_Recoil_Default
	{
		muzzleOuter[] = {0.5,1,0.6,0.4};
		kickBack[] = {0.04,0.05};
		temporary = 0.01;
	};
	class WPS_Recoil_Z6: WPS_Recoil_Default
	{
		muzzleOuter[] = {0.4,1.3,0.7,0.25};
		kickBack[] = {0.015,0.05};
		temporary = 0.005;
	};
	class WPS_Recoil_DLT18: WPS_Recoil_Default
	{
		kickBack[] = {0.05,0.09};
		permanent = 1;
	};
	class WPS_Recoil_DX11: WPS_Recoil_Default
	{
		kickBack[] = {0.03,0.07};
		temporary = 0.04;
	};
};
