// Type Defines to make scope simpler to define
#define Private 0
#define Protected 1
#define Public 2
